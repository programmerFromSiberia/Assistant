﻿namespace AIInterviewAssistant.MAUIApp;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
    }
}