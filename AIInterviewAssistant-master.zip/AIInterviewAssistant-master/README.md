> [!NOTE]
> This is MVP version that was made just for fun, code is shitty!
> Supported lang: ru

<div align="center">

  # AI interview assistant.

  ## How it works?
  * Settings (also GPT Token) located in **MauiProgram.cs**
  * Download VOSK model from here: https://alphacephei.com/vosk/models
  * Unpack it and paste folder path in second input.
  * Write in the first input your position.
  * Click LOAD button and wait when model will be loaded (Check status string on the bottom of app)
  * When model is loaded use keyboard ARROW keys
  * Arrow left - record desktop audio
  * Arrow right - record default input device
  * If text will be corrupted, you can modify it and press "Send manual" button

</div>
